# Importando clases
from .persona import Persona
from .recurso import Recurso
from .asignacion import Asignacion
from .CasoLegal import ProcesoLegal